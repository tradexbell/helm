create user "instrument";
alter user "instrument" with PASSWORD 'instrument';
create schema "instrument";
alter schema "instrument" owner to "instrument";
