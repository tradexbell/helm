create user "attachment";
alter user "attachment" with PASSWORD 'attachment';
create schema "attachment";
alter schema "attachment" owner to "attachment";
