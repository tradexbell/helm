create user "advertising";
alter user "advertising" with PASSWORD 'advertising';
create schema "advertising";
alter schema "advertising" owner to "advertising";
