create user "configuration";
alter user "configuration" with PASSWORD 'configuration';
create schema "configuration";
alter schema "configuration" owner to "configuration";
