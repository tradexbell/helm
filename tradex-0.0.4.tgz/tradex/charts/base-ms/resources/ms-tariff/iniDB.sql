create user "tariff";
alter user "tariff" with PASSWORD 'tariff';
create schema "tariff";
alter schema "tariff" owner to "tariff";
