create user "user";
alter user "user" with PASSWORD 'user';
create schema "user";
alter schema "user" owner to "user";
