create user "bridge-adapter";
alter user "bridge-adapter" with PASSWORD 'bridge-adapter';
create schema "bridge-adapter";
alter schema "bridge-adapter" owner to "bridge-adapter";
