create user "market-data-history";
alter user "market-data-history" with PASSWORD 'market-data-history';
create schema "market-data-history";
alter schema "market-data-history" owner to "market-data-history";
