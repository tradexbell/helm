CREATE USER log IDENTIFIED WITH plaintext_password BY 'log';
CREATE DATABASE log;
GRANT ALL ON log.* TO log;