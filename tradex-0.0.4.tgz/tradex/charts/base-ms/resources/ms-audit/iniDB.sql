create user "audit";
alter user "audit" with PASSWORD 'audit';
create schema "audit";
alter schema "audit" owner to "audit";
