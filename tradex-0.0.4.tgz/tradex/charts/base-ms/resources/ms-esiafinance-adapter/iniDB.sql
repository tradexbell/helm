create user "esiafinance-adapter";
alter user "esiafinance-adapter" with PASSWORD 'esiafinance-adapter';
create schema "esiafinance-adapter";
alter schema "esiafinance-adapter" owner to "esiafinance-adapter";
