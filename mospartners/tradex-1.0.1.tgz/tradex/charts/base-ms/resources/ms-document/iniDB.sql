create user "document";
alter user "document" with PASSWORD 'document';
create schema "document";
alter schema "document" owner to "document";
