create user "dictionary";
alter user "dictionary" with PASSWORD 'dictionary';
create schema "dictionary";
alter schema "dictionary" owner to "dictionary";
