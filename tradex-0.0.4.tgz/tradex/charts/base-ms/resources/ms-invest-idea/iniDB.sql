create user "invest-idea";
alter user "invest-idea" with PASSWORD 'invest-idea';
create schema "invest-idea";
alter schema "invest-idea" owner to "invest-idea";
