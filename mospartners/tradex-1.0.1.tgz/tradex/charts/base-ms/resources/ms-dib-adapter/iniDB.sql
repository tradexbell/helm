create user "dib-adapter";
alter user "dib-adapter" with PASSWORD 'dib-adapter';
create schema "dib-adapter";
alter schema "dib-adapter" owner to "dib-adapter";
