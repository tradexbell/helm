create user "poll";
alter user "poll" with PASSWORD 'poll';
create schema "poll";
alter schema "poll" owner to "poll";
