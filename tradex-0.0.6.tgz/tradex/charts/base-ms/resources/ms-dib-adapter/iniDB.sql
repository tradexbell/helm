create user "partners-adapter";
alter user "partners-adapter" with PASSWORD 'partners-adapter';
create schema "partners-adapter";
alter schema "partners-adapter" owner to "partners-adapter";
