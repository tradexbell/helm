create user "schedule";
alter user "schedule" with PASSWORD 'schedule';
create schema "schedule";
alter schema "schedule" owner to "schedule";
