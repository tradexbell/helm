create user "acquire";
alter user "acquire" with PASSWORD 'acquire';
create schema "acquire";
alter schema "acquire" owner to "acquire";
