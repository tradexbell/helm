create user "assignment";
alter user "assignment" with PASSWORD 'assignment';
create schema "assignment";
alter schema "assignment" owner to "assignment";
