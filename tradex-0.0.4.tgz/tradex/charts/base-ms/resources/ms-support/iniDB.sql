create user "support";
alter user "support" with PASSWORD 'support';
create schema "support";
alter schema "support" owner to "support";
