create user "portfolio";
alter user "portfolio" with PASSWORD 'portfolio';
create schema "portfolio";
alter schema "portfolio" owner to "portfolio";
